UPDATE  st_addons SET version="1.0.5"
WHERE uuid = "F6JyoUM3udQvNeJZS2l+BIIrhhrqY1JpsUi6UUDCrANJXIqwEwN9lp4ypv+HBshQFAdLbejgJzSCbw==";
COMMIT;