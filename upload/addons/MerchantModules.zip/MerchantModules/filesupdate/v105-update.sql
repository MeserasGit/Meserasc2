UPDATE  st_addons SET version="1.0.5"
WHERE uuid = "QSbusF9pPoZNlJlw8ZG6yOF3RJU+EttSlL7rY7S13wUYWKKxhIPi+3MbH5bAXIn3gbtUmUkpTFjkVnBl";

COMMIT;