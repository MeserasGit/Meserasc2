
INSERT INTO `st_addons` (`id`, `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
(null, 'Merchant app', 'QSbusF9pPoZNlJlw8ZG6yOF3RJU+EttSlL7rY7S13wUYWKKxhIPi+3MbH5bAXIn3gbtUmUkpTFjkVnBl', '1.0.5', 1, 'merchantapp_banner.png', 'upload/all', '', now(), now(), '127.0.0.1');

COMMIT;