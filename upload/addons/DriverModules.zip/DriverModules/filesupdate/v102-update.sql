UPDATE  st_addons SET version="1.0.2"
WHERE uuid = "7EewaLXhXX50fWBCC+Gg3r4M4UpUwi6CWtH+y/GHPjC6bcd66lXfETwz7nO/5HYmkcmNURCAov8Vgg==";
COMMIT;