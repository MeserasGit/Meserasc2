import{h as e,s as a}from"./index.9022de34.js";const s=e("div",{class:"q-space"});var c=a({name:"QSpace",setup(){return()=>s}});export{c as Q};
