function e(){const t=new Map;return{getCache:function(n,c){return t[n]===void 0?t[n]=c:t[n]},getCacheWithFn:function(n,c){return t[n]===void 0?t[n]=c():t[n]}}}export{e as u};
